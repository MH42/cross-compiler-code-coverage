package org.apache.hupa.shared.data;


import tc3.shared.InstrumentationLoggerProvider;

public interface HasId {
   String getId();
}
