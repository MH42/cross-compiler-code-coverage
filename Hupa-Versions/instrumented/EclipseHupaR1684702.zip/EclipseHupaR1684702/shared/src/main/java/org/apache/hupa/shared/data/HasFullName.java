package org.apache.hupa.shared.data;


import tc3.shared.InstrumentationLoggerProvider;

public interface HasFullName {
   String getFullName();
   void setFullName(String name);
}
