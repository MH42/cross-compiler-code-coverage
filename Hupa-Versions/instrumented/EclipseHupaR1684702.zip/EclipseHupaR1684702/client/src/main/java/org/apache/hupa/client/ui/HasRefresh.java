package org.apache.hupa.client.ui;


import tc3.shared.InstrumentationLoggerProvider;

public interface HasRefresh{
    void refresh();
}