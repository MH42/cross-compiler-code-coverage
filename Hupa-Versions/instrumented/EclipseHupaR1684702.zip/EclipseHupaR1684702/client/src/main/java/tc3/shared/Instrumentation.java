package tc3.shared;
public interface Instrumentation {
	public void instrument(String nodeIdentifier);
}