package org.apache.hupa.client.ui;


import tc3.shared.InstrumentationLoggerProvider;

public interface HupaPlugins {

    public static class HupaDefaultPlugins implements HupaPlugins {

    }




}
