package org.apache.hupa.client.place;


import tc3.shared.InstrumentationLoggerProvider;

public class HupaPlace extends AbstractPlace{public HupaPlace(){
	  InstrumentationLoggerProvider.get().instrument("org_apache_hupa_client_place_HupaPlace_java0x09262febd0x1_____org_apache_hupa_client_place_HupaPlace_java0x09262febd0x0_____org_apache_hupa_client_place_HupaPlace_java0x09262febd");
	}
	



}
