About the com.google.gwt.gen2.event.shared.HandlerManager:
See http://code.google.com/p/google-web-toolkit-incubator/issues/detail?id=340
